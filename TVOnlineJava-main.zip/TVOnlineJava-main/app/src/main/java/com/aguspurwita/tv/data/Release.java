package com.aguspurwita.tv.data;

import java.util.List;

public class Release
{
    public int versionCode;
    public String versionName;
    public List<String> changelog;
    public String downloadUrl;
}
