package com.aguspurwita.tv.data;

import java.util.ArrayList;

public class Playlist {
    public ArrayList<License> licenses;
    public ArrayList<Category> categories;
    public ArrayList<Channel> channels;
}