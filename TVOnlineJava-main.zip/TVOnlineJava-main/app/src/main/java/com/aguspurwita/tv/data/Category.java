package com.aguspurwita.tv.data;

public class Category {
    public int id;
    public String name;
}
