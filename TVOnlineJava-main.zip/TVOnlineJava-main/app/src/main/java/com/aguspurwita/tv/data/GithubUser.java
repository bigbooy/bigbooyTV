package com.aguspurwita.tv.data;

public class GithubUser {
    public String login;
    public String url;
    public int contributions;
}
